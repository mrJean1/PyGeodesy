
# -*- coding: utf-8 -*-

'''Six different functions to I{simplify} or linearize a path given as a
list, sequence or tuple of I{LatLon} points.

Each of the simplify functions is based on a different algorithm and
produces different simplified results in (very) different run times
for the same path of I{LatLon} points.

Function L{simplify1} eliminates points based on edge length.  Function
L{simplify2} slides a pipe over each edge, removing subsequent points
up to the first point outside the pipe.

The functions L{simplifyRDP} and L{simplifyRDPm} use the original,
respectively modified Ramer-Douglas-Peucker (RDP) algorithm, recursively
finding the points farthest from each path edge.  The difference is that
function L{simplifyRDP} exhaustively searches the single, most distant
point in each iteration, while function L{simplifyRDPm} stops at the
first point exceeding the distance tolerance.

Functions L{simplifyVW} and L{simplifyVWm} are based on the original,
respectively modified Visvalingam-Whyatt (VW) method using the area of
the triangle formed by three neigboring points.  The original L{simplifyVW}
method removes only a single point per iteration, while the modified
L{simplifyVWm} removes all points with areas not exceeding the
tolerance in each iteration.

Functions L{simplify2}, L{simplifyRDP} and L{simplifyRDPm} provide
keyword I{shortest} to select the computation of the distance between
a point and a path edge.  If True, use the shortest distance to the
path edge or path end points, False use the perpendicular distance to
the extended path edge line.

For all functions, keyword I{adjust} scales the longitudinal distance
between two points by the cosine of the mean of the latitudes.

See:
 - U{http://bost.ocks.org/mike/simplify/}
 - U{http://wikipedia.org/wiki/Ramer-Douglas-Peucker_algorithm}
 - U{http://hydra.hull.ac.uk/resources/hull:8338}
 - U{http://www.cs.ubc.ca/cgi-bin/tr/1992/TR-92-07.pdf}
 - U{http://web.cs.sunyit.edu/~poissad/projects/Curve/about_project.php}
 - U{http://www.bdcc.co.uk/Gmaps/GDouglasPeuker.js}
 - U{http://github.com/mourner/simplify-js/}
 - U{http://github.com/omarestrella/simplify.py/}
 - U{http://pypi.python.org/pypi/visvalingam}
 - U{http://pypi.python.org/pypi/simplification/}

Tested with 64-bit Python 2.6.9, 2.7.13, 3.5.3 and 3.6.0 on macOS
10.12.3, 10.12.4 and 10.12.5 Sierra.

@newfield example: Example, Examples
'''

from datum import R_M
from utils import EPS, len2, radiansPI, wrap90, wrap180

from math  import cos, degrees, radians, sqrt

__all__ = ('simplify1', 'simplify2',
           'simplifyRDP', 'simplifyRDPm',
           'simplifyVW', 'simplifyVWm')
__version__ = '17.06.02'


# try:
#     from collections import namedtuple
#     _T2 = namedtuple('_T2', 'ix, h2')
# except ImportError:
#    class _T2(object):
#        ...
# namedtuple not used because (a) values can not
# be updated and (b) it produces PyChecker warning
# "<string>:28: self is not first method argument"
# which can not be suppressed by option --stdlib
class _T2(object):
    '''(INTERNAL) VW 2-tuple (index, area).
    '''
    __slots__ = 'ix', 'h2'

    def __init__(self, ix, h2):
        self.ix = ix
        self.h2 = h2


class _Sy(object):
    '''(INTERNAL) Simplify state.
    '''
    adjust = False
    d2i    = None  # d2iP or d2iS
    d2xyse = ()
    eps    = EPS  # system epsilon
    n      = 0
    pts    = []
    radius = R_M  # mean earth radius
    r      = {}   # RDP indices or VW 2-tuples
    s2     = EPS  # tolerance squared
    s2e    = EPS  # sentinel

    def __init__(self, points, tolerance, radius, adjust, shortest):
        '''New state.
        '''
        n, self.pts = len2(points)
        if n > 0:
            self.n = n
            self.r = {0: True, n-1: True}  # dict to avoid duplicates

        if adjust:
            self.adjust = True

        if radius:
            self.radius = float(radius)
        if self.radius < self.eps:
            raise ValueError('%s too small: %.6e' % ('radius', radius))

        # tolerance converted to degrees squared
        self.s2 = degrees(tolerance / self.radius) ** 2
        if min(self.s2, tolerance) < self.eps:
            raise ValueError('%s too small: %.6e' % ('tolerance', tolerance))
        self.s2e = self.s2 + 1  # sentinel

        # compute either the shortest or perpendicular distance
        self.d2i = self.d2iS if shortest else self.d2iP  # PYCHOK false

    def d21(self, s, e):
        '''Sets path edge or line thru points[s] to -[e].
        '''
        d21, x21, y21 = self.d2xy(s, e)
        self.d2xyse = d21, x21, y21, s, e
        return d21 > self.eps

    def d2iP(self, n, m, brk):
        '''Finds the tallest perpendicular distance among all
           points[n..m] to the path edge or line thru points[s]
           to -[e] exceeding the tolerance.
        '''
        d21, x21, y21, s, _ = self.d2xyse
        eps, d2xy = self.eps, self.d2xy
        t2, t = self.s2, 0  # tallest
        for i in range(n, m):
            d2, x01, y01 = d2xy(s, i)
            if d2 > eps:
                # perpendicular distance
                d2 = ((x01 * y21 + y01 * x21) ** 2) / d21
                if d2 > t2:
                    t2, t = d2, i
                    if brk:
                        break
        return t2, t

    def d2iS(self, n, m, brk):
        '''Finds the tallest shortest distance among all
           points[n..m] to the path edge or line thru
           points[s] to -[e] exceeding the tolerance.
        '''
        d21, x21, y21, s, e = self.d2xyse
        eps, d2xy = self.eps, self.d2xy
        t2, t = self.s2, 0  # tallest
        for i in range(n, m):
            # distance points[i] to -[s]
            d2, x01, y01 = d2xy(s, i)
            if d2 > eps:
                x = x01 * x21 - y01 * y21
                if x > 0:
                    if (x * x) < d21:
                        # perpendicular distance
                        d2 = ((x01 * y21 + y01 * x21) ** 2) / d21
                    else:  # distance points[i] to -[e]
                        d2, _, _ = d2xy(e, i)
                if d2 > t2:
                    t2, t = d2, i
                    if brk:
                        break
        return t2, t

    def d2xy(self, i, j):
        '''Returns points[i] to [j] deltas.
        '''
        p1 = self.pts[i]
        p2 = self.pts[j]

        # like the Equirectangular Approximation/Projection at
        # <http://www.movable-type.co.uk/scripts/latlong.html>
        # but using degrees as units instead of meter

        dx = wrap180(p2.lon - p1.lon)
        dy = wrap90 (p2.lat - p1.lat)

        if self.adjust:  # scale lon
            dx *= cos(radiansPI(p1.lat + p2.lat) * 0.5)

        d2 = dx * dx + dy * dy  # squared!
        return d2, dx, dy

    def h2t(self, i1, i0, i2):
        '''Computes the Visvalingam-Whyatt triangular area,
           points[i1] to -[i2] form the base and points[i0]
           is the top of the triangle.
        '''
        d21, x21, y21 = self.d2xy(i1, i2)
        if d21 > self.eps:
            d01, x01, y01 = self.d2xy(i1, i0)
            if d01 > self.eps:
                h2 = abs(x01 * y21 + y01 * x21)
                # triangle height h = h2 / sqrt(d21) and
                # the area = h * sqrt(d21) / 2 == h2 / 2
                return h2  # double triangle area
        return 0

    def points(self, r):
        '''Returns the list of simplified points.
        '''
        return [self.pts[i] for i in sorted(r.keys())]

    def rdp(self, mod):
        '''Ramer-Douglas-Peucker (RDP) simplification of a
           path of I{LatLon} points.

           @param mod: Modified RDP (bool).
        '''
        n, r = self.n, self.r
        if n > 1:
            s2, d21, d2i = self.s2, self.d21, self.d2i

            se = [(0, n-1)]
            while se:
                s, e = se.pop()
                if (e - s) > 1:
                    if d21(s, e):
                        d2, i = d2i(s+1, e, mod)
                        if i > 0 and d2 > s2:
                            r[s] = r[i] = True
                            se.append((i, e))
                            if not mod:
                                se.append((s, i))
                        else:
                            r[s] = True
                    else:  # split halfway
                        i = (e + s) // 2
                        se.append((i, e))
                        se.append((s, i))

        return self.points(r)

    def rm1(self, m, tol):
        '''Eliminates one Visvalingam-Whyatt point and recomputes
           the trangular area of both neighboring points, but
           removes those too unless the recomputed area exceeds
           the tolerance.
        '''
        h2t, r = self.h2t, self.r

        r.pop(m)
        for n in (m, m - 1):
            while 0 < n < (len(r) - 1):
                h2 = h2t(r[n-1].ix, r[n].ix, r[n+1].ix)
                if h2 > tol:
                    r[n].h2 = h2
                    break  # while
                else:
                    r.pop(n)

    def rm2(self, tol):
        '''Eliminates all Visvalingam-Whyatt points with a
           triangular area not exceeding the tolerance.
        '''
        r, rm1 = self.r, self.rm1

        i = len(r) - 1
        while i > 1:
            i -= 1
            if r[i].h2 <= tol:
                rm1(i, tol)
                i = min(i, len(r) - 1)

    def vwn(self):
        '''Initializes Visvalingam-Whyatt as list of 2-Tuples
           (ix, h2) where ix is the points[] index and h2
           the triangular area (times 2) of that point.
        '''
        n, h2t, s2e = self.n, self.h2t, self.s2e

        if n > 2:
            self.r = [_T2(0, s2e)]
            self.r.extend(_T2(i, h2t(i-1, i, i+1)) for i in range(1, n-1))
            self.r.append(_T2(n-1, s2e))
        elif n > 0:
            self.r = [_T2(i, s2e) for i in range(0, n)]  # PYCHOK false
        else:
            self.r = []

        return len(self.r)

    def vwr(self, attr):
        '''Returns Visvalingam-Whyatt results, optionally
           including the triangular area (in meters) as
           attribute attr to each simplified point.
        '''
        pts, r = self.pts, self.r

        # double check the minimal triangular area
        assert min(t2.h2 for t2 in r) > self.s2 > 0

        if attr:  # return the trangular area (actually
            # the sqrt of double the triangular area)
            # converted back from degrees to meter
            m = radians(1.0) * self.radius
            r[0].h2 = r[-1].h2 = 0  # zap sentinels
            for t2 in r:  # convert back to meter
                setattr(pts[t2.ix], attr, sqrt(t2.h2) * m)

        # double check for duplicates
        n = len(r)
        r = dict((t2.ix, True) for t2 in r)
        assert len(r) == n
        return self.points(r)


def simplify1(points, distance, radius=R_M, adjust=True):
    '''Basic simplification of a path of I{LatLon} points.

       Eliminates any points closer together than the given
       distance tolerance.

       @param points: Path points (I{LatLon}s).
       @param distance: Tolerance (meter, same units as radius).
       @keyword radius: Earth radius (meter).
       @keyword adjust: Adjust longitudes (bool).

       @return: Simplified points (list of I{LatLon}s).

       @raise ValueError: Radius or distance tolerance too small.
    '''
    S = _Sy(points, distance, radius, adjust, True)

    n, r = S.n, S.r
    if n > 1:
        s2, d2xy = S.s2, S.d2xy

        i = 0
        for j in range(1, n):
            d2, _, _ = d2xy(i, j)
            if d2 > s2:
                r[j] = True
                i = j

    return S.points(r)


def simplify2(points, pipe, radius=R_M, adjust=True, shortest=False):
    '''Pipe simplification of a path of I{LatLon} points.

       Eliminates any points too close together or within the given
       pipe tolerance along an edge.

       @param points: Path points (I{LatLon}s).
       @param pipe: Half pipe width (meter, same units as radius).
       @keyword radius: Earth radius (meter).
       @keyword adjust: Adjust longitudes (bool).
       @keyword shortest: Shortest or perpendicular distance (bool).

       @return: Simplified points (list of I{LatLon}s).

       @raise ValueError: Radius or pipe tolerance too small.
    '''
    S = _Sy(points, pipe, radius, adjust, shortest)

    n, r = S.n, S.r
    if n > 1:
        s2, d21, d2i = S.s2, S.d21, S.d2i

        s, e = 0, 1
        while s < e < n:
            if d21(s, e):
                d2, i = d2i(e+1, n, True)
                if i > 0 and d2 > s2:
                    r[s] = r[i] = True
                    s, e = i, i + 1
                else:
                    r[s] = True  # r[n-1] = True
                    break  # while loop
            else:  # drop points[e]
                e += 1

    return S.points(r)


def simplifyRDP(points, distance, radius=R_M, adjust=True, shortest=False):
    '''Ramer-Douglas-Peucker (RDP) simplification of a path of
       I{LatLon} points.

       Eliminates any points too close together or closer to an
       edge than the given distance tolerance.

       This RDP method exhaustively searches for the point with
       the largest distance, resulting in worst-case complexity
       O(n**2) where n is the number of points.

       @param points: Path points (I{LatLon}s).
       @param distance: Tolerance (meter, same units as radius).
       @keyword radius: Earth radius (meter).
       @keyword adjust: Adjust longitudes (bool).
       @keyword shortest: Shortest or perpendicular distance (bool).

       @return: Simplified points (list of I{LatLon}s).

       @raise ValueError: Radius or distance tolerance too small.
    '''
    S = _Sy(points, distance, radius, adjust, shortest)

    return S.rdp(False)


def simplifyRDPm(points, distance, radius=R_M, adjust=True, shortest=False):
    '''Modified Ramer-Douglas-Peucker (RDP) simplification of a path
       of I{LatLon} points.

       Eliminates any points too close together or closer to an edge
       than the given distance tolerance.

       This RDP method stops at the first point farther than the
       given distance tolerance, significantly reducing the run time
       (but producing results different from the original RDP method).

       @param points: Path points (I{LatLon}s).
       @param distance: Tolerance (meter, same units as radius).
       @keyword radius: Earth radius (meter).
       @keyword adjust: Adjust longitudes (bool).
       @keyword shortest: Shortest or perpendicular distance (bool).

       @return: Simplified points (list of I{LatLon}s).

       @raise ValueError: Radius or distance tolerance too small.
    '''
    S = _Sy(points, distance, radius, adjust, shortest)

    return S.rdp(True)


def simplifyVW(points, area, radius=R_M, adjust=True, attr=None):
    '''Visvalingam-Whyatt (VW) simplification of a path of I{LatLon}
       points.

       Eliminates any points too close together or with a triangular
       area not exceeding the given area tolerance (squared).

       This VW method exhaustively searches for the single point
       with the smallest triangular area, resulting in worst-case
       complexity O(n**2) where n is the number of points.

       @param points: Path points (I{LatLon}s).
       @param area: Tolerance (meter, same units as radius).
       @keyword radius: Earth radius (meter).
       @keyword adjust: Adjust longitudes (bool).
       @keyword attr: Points attribute save area value (string).

       @return: Simplified points (list of I{LatLon}s).

       @raise ValueError: Radius or area tolerance too small.
    '''
    S = _Sy(points, area, radius, adjust, False)

    if S.vwn() > 2:
        # remove any points too close or
        # with a zero triangular area
        S.rm2(0)

        r, s2, s2e = S.r, S.s2, S.s2e
        # keep removing the point with the smallest
        # area until latter exceeds the tolerance
        while len(r) > 2:
            m, m2 = 0, s2e
            for i in range(1, len(r) - 1):
                h2 = r[i].h2
                if h2 < m2:
                    m, m2 = i, h2
            if m2 > s2:
                break
            S.rm1(m, 0)

    return S.vwr(attr)


def simplifyVWm(points, area, radius=R_M, adjust=True, attr=None):
    '''Modified Visvalingam-Whyatt (VW) simplification of a path of
       I{LatLon} points.

       Eliminates any points too close together or with a triangular
       area not exceeding the given area tolerance (squared).

       This VW method removes all points with a triangular area
       below the tolerance per iteration, significantly reducing the
       run time (but producing results different from the original
       VW method).

       @param points: Path points (I{LatLon}s).
       @param area: Tolerance (meter, same units as radius).
       @keyword radius: Earth radius (meter).
       @keyword adjust: Adjust longitudes (bool).
       @keyword attr: Attribute to save the area value (string).

       @return: Simplified points (list of I{LatLon}s).

       @raise ValueError: Radius or area tolerance too small.
    '''
    S = _Sy(points, area, radius, adjust, False)

    if S.vwn() > 2:
        # remove all points with an area
        # not exceeding the tolerance
        S.rm2(S.s2)

    return S.vwr(attr)

# **) MIT License
#
# Copyright (C) 2016-2017 -- mrJean1 at Gmail dot com
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included
# in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
# OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
# ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
# OTHER DEALINGS IN THE SOFTWARE.
