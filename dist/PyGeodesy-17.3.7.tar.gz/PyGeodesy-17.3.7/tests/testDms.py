
# -*- coding: utf-8 -*-

# Test degrees, minutes, seconds functions.

__all__ = ('Tests',)
__version__ = '17.03.07'

from tests import Tests as _Tests

from geodesy import F_D, F_DM, F_DMS, \
                    compassPoint, parse3llh, parseDMS, toDMS


class Tests(_Tests):

    def testDms(self):
        # dms module tests
        self.test('parseDMS', parseDMS(  '0.0°'), '0.0')
        self.test('parseDMS', parseDMS(    '0°'), '0.0')
        self.test('parseDMS', parseDMS('''000°00'00"'''),   '0.0')
        self.test('parseDMS', parseDMS('''000°00'00.0"'''), '0.0')
        self.test('parseDMS', parseDMS('''000° 00'00"'''),    '0.0')
        self.test('parseDMS', parseDMS('''000°00 ' 00.0"'''), '0.0')

        x = parse3llh('000° 00′ 05.31″W, 51° 28′ 40.12″ N')
        x = ', '.join('%.6f' % a for a in x)  # XXX fStr
        self.test('parse3llh', x, '51.477811, -0.001475, 0.000000')

        for a, x in (((),            '''45°45'45.36"'''),
                     ((F_D, None),     '45.7626°'),
                     ((F_DM, None),    "45°45.756'"),
                     ((F_DMS, None), '''45°45'45.36"'''),
                     ((F_D, 6),     '45.7626°'),
                     ((F_DM, -4),   "45°45.7560'"),
                     ((F_DMS, 2), '''45°45'45.36"''')):
            self.test('toDMS', toDMS(45.76260, *a), x)

        for a, x in (((1,),   'N'),
                     ((0,),   'N'),
                     ((-1,),  'N'),
                     ((359,), 'N'),
                     ((24,),   'NNE'),
                     ((24, 1), 'N'),
                     ((24, 2), 'NE'),
                     ((24, 3), 'NNE'),
                     ((226,),   'SW'),
                     ((226, 1), 'W'),
                     ((226, 2), 'SW'),
                     ((226, 3), 'SW'),
                     ((237,),   'WSW'),
                     ((237, 1), 'W'),
                     ((237, 2), 'SW'),
                     ((237, 3), 'WSW')):
            self.test('compassPoint', compassPoint(*a), x)


if __name__ == '__main__':

    from geodesy import dms  # private

    t = Tests(__file__, __version__, dms)
    t.testDms()
    t.results()
    t.exit()

    # Typical test results (on MacOS 10.12.3):

    # testing geodesy.dms version 17.02.15
    # test 1 parseDMS: 0.0
    # test 2 parseDMS: 0.0
    # test 3 parseDMS: 0.0
    # test 4 parseDMS: 0.0
    # test 5 parseDMS: 0.0
    # test 6 parseDMS: 0.0
    # test 7 parse3llh: 51.477811, -0.001475, 0.000000
    # test 8 toDMS: 45°45′45.36″
    # test 9 toDMS: 45.7626°
    # test 10 toDMS: 45°45.756′
    # test 11 toDMS: 45°45′45.36″
    # test 12 toDMS: 45.7626°
    # test 13 toDMS: 45°45.7560′
    # test 14 toDMS: 45°45′45.36″
    # test 15 compassPoint: N
    # test 16 compassPoint: N
    # test 17 compassPoint: N
    # test 18 compassPoint: N
    # test 19 compassPoint: NNE
    # test 20 compassPoint: N
    # test 21 compassPoint: NE
    # test 22 compassPoint: NNE
    # test 23 compassPoint: SW
    # test 24 compassPoint: W
    # test 25 compassPoint: SW
    # test 26 compassPoint: SW
    # test 27 compassPoint: WSW
    # test 28 compassPoint: W
    # test 29 compassPoint: SW
    # test 30 compassPoint: WSW
    # all geodesy.dms tests passed (Python 2.7.13 64bit)

    # testing dms version 17.02.15
    # test 1 parseDMS: 0.0
    # test 2 parseDMS: 0.0
    # test 3 parseDMS: 0.0
    # test 4 parseDMS: 0.0
    # test 5 parseDMS: 0.0
    # test 6 parseDMS: 0.0
    # test 7 parse3llh: 51.477811, -0.001475, 0.000000
    # test 8 toDMS: 45°45′45.36″
    # test 9 toDMS: 45.7626°
    # test 10 toDMS: 45°45.756′
    # test 11 toDMS: 45°45′45.36″
    # test 12 toDMS: 45.7626°
    # test 13 toDMS: 45°45.7560′
    # test 14 toDMS: 45°45′45.36″
    # test 15 compassPoint: N
    # test 16 compassPoint: N
    # test 17 compassPoint: N
    # test 18 compassPoint: N
    # test 19 compassPoint: NNE
    # test 20 compassPoint: N
    # test 21 compassPoint: NE
    # test 22 compassPoint: NNE
    # test 23 compassPoint: SW
    # test 24 compassPoint: W
    # test 25 compassPoint: SW
    # test 26 compassPoint: SW
    # test 27 compassPoint: WSW
    # test 28 compassPoint: W
    # test 29 compassPoint: SW
    # test 30 compassPoint: WSW
    # all dms tests passed (Python 3.6.0 64bit)
