
# -*- coding: utf-8 -*-

from setuptools import setup


def _version():
    with open('geodesy/__init__.py') as f:
        for t in f:
            if t.startswith('__version__'):
                return t.split('=')[-1].strip().strip("'")


def _long_description():
    with open('README.txt') as f:
          return f.read()


setup(
    name='PyGeodesy',
    packages=['geodesy', 'tests'],
    description='Python geodesy tools',
    version=_version(),

    author='Jean M. Brouwers',
    author_email='mrJean1@Gmail.com',
    maintainer='Jean M. Brouwers',
    maintainer_email='mrJean1@Gmail.com',

    license='MIT',
    keywords='geodesy datum earth ellipsoid Lambert MGRS Nvector OSGR sphere trigonometry UTM Vincenty',
    url='https://github.com/mrJean1/PyGeodesy',

    long_description=_long_description(),

    package_data={'geodesy': ['LICENSE']},

    zip_safe=False,
    classifiers=[
        'Development Status :: 4 - Beta',  # 5 - Production/Stable',
        'Environment :: Console',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Programming Language :: Python :: 2.6',
        'Programming Language :: Python :: 2.7',
        'Programming Language :: Python :: 3.5',
        'Programming Language :: Python :: 3.6',
        'Topic :: Software Development',
        'Topic :: Scientific/Engineering :: GIS',
    ],

#   download_url='https://github.com/mrJean1/PyGeodesy',
#   entry_points={},
#   include_package_data=False,
#   install_requires=[],
#   namespace_packages=[],
#   py_modules=[],
#   test_suite='testsuite.test_all.suite',
)
