
# -*- coding: utf-8 -*-

# Test the Hausdorff distances.

__all__ = ('Tests',)
__version__ = '19.08.14'

from base import geographiclib, isPython3, TestsBase

from pygeodesy import fStr, LatLon_, randomrangenerator

_rr = randomrangenerator('R')
# like <https://GitHub.com/mavillan/py-hausdorff> Example
_ms = [LatLon_(*_ll) for _ll in zip(_rr( -90,  90, 2),  # 90
                                    _rr(-180, 180, 4))]

_ps = [LatLon_(*_ll) for _ll in zip(_rr( -89,  90, 3),  # 60
                                    _rr(-179, 180, 6))]


class Tests(TestsBase):

    def test4(self, Hausdorff, *tests, **kwds):

        def _tstr(t):
            s = list(t[:5])
            s[0] = fStr(t.hd, prec=5)
            s[4] = None if t.md is None else fStr(t.md, prec=5)
            return '(%s)' % (', '.join(map(str, s)),)

        for s, e, x, y in tests:
            h = Hausdorff(_ms, seed=s, **kwds)

            t = _tstr(h.directed(_ps, early=e))
            self.test(h.named, t, x)  # + (h.units,)

            t = _tstr(h.symmetric(_ps, early=e))
            self.test(h.named, t, y)  # + (h.units,)


if __name__ == '__main__':

    from pygeodesy import Datums, \
                          HausdorffDegrees, HausdorffRadians, \
                          HausdorffEquirectangular, HausdorffEuclidean, \
                          HausdorffHaversine, HausdorffKarney, \
                          HausdorffVincentys

    class HausdorffDegrees_(HausdorffDegrees):
        '''Custom Hausdorff.'''
        def distance(self, p1, p2):
            dy, dx = abs(p1.lat - p2.lat), abs(p1.lon - p2.lon)
            if dx < dy:
                dx, dy = dy, dx
            return dx + dy * 0.5

    class HausdorffRadians_(HausdorffRadians):
        '''Custom Hausdorff.'''
        def distance(self, p1, p2):
            dy, dx = abs(p1.a - p2.a), abs(p1.b - p2.b)
            if dx < dy:
                dx, dy = dy, dx
            return dx + dy * 0.5

    def _4(t5directed, t5symmetric):
        # generate Hausdorff(*args) and results for
        # 4 different seed= and early= test cases
        yield None, False, t5directed, t5symmetric
        yield 'X',  False, t5directed, t5symmetric

        t4directed  = t5directed[:4] + (None,)
        t4symmetric = t5symmetric[:4] + (None,)
        yield None, True, t4directed, t4symmetric
        yield 'X',  True, t4directed, t4symmetric

    t = Tests(__file__, __version__)

    # check repeatable random ranges
    r1 = randomrangenerator('R')
    r2 = randomrangenerator('R')
    for n in (0, 1, 2, 8, 32, 128):
        t.test('randomrange[%d]' % (n,), tuple(r1(n)), tuple(r2(n)))

    if isPython3:  # XXX different Random?
        t.test4(HausdorffDegrees_, *_4((40.0, 22,  6,  90, 18.16111),
                                       (48.0, 38, 36, 150, 17.30667)))

        t.test4(HausdorffRadians_, *_4((0.69813, 22,  6,  90, 0.31697),
                                       (0.83776, 38, 36, 150, 0.30206)))

        t.test4(HausdorffEquirectangular, *_4((0.25113, 35,  3,  90, 0.05965),
                                              (0.25113, 35,  3, 150, 0.05532)))

        t.test4(HausdorffEuclidean, *_4((0.5434, 56, 51,  90, 0.23356),  # XXX different i, j?
                                        (0.5434, 56, 51, 150, 0.22296)))

        t.test4(HausdorffHaversine, *_4((0.50097, 35, 3,  90, 0.212),
                                        (0.50097, 35, 3, 150, 0.20099)))

        t.test4(HausdorffVincentys, *_4((0.50097, 35, 3,  90, 0.212),
                                        (0.50097, 35, 3, 150, 0.20099)))

        if geographiclib:
            t.test4(HausdorffKarney, *_4((28.79903, 35, 3,  90, 12.16138),
                                         (28.79903, 35, 3, 150, 11.53021)),
                                     datum=Datums.WGS84)
    else:  # Python 2
        t.test4(HausdorffDegrees_, *_4((50.5, 61, 7,  90, 18.45556),
                                       (50.5, 61, 7, 150, 16.05)))

        t.test4(HausdorffRadians_, *_4((0.88139, 61, 7,  90, 0.32211),
                                       (0.88139, 61, 7, 150, 0.28013)))

        t.test4(HausdorffEquirectangular, *_4((0.33016, 49, 29,  90, 0.06075),
                                              (0.33016, 49, 29, 150, 0.04918)))

        t.test4(HausdorffEuclidean, *_4((0.6418, 49, 29,  90, 0.22056),
                                        (0.6418, 49, 29, 150, 0.19676)))

        t.test4(HausdorffHaversine, *_4((0.56202, 49, 29,  90, 0.19776),
                                        (0.56202, 49, 29, 150, 0.176)))

        t.test4(HausdorffVincentys, *_4((0.56202, 49, 29,  90, 0.19776),
                                        (0.56202, 49, 29, 150, 0.176)))

        if geographiclib:
            t.test4(HausdorffKarney, *_4((32.28234, 49, 29,  90, 11.34653),
                                         (32.28234, 49, 29, 150, 10.09914)),
                                     datum=Datums.WGS84)
    t.results()
    t.exit()
