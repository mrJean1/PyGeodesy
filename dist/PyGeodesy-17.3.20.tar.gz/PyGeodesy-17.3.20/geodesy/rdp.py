#!/usr/bin/env python


# -*- coding: utf-8 -*-

'''Ramer-Douglas-Peucker linearization of a path.

See:
 - U{http://www.bdcc.co.uk/Gmaps/GDouglasPeuker.js}
 - U{https://github.com/mourner/simplify-js/}

See also:
 - U{https://github.com/omarestrella/simplify.py/}
 - U{https://bost.ocks.org/mike/simplify/}
 - U{https://pypi.python.org/pypi/visvalingam}
 - U{https://pypi.python.org/pypi/simplification/}
 - U{https://news.ycombinator.com/item?id=4055445}

Tested with 64-bit Python 2.7.13 and 3.6.0 on macOS X 10.12.3 Sierra.

@newfield example: Example, Examples
'''

from datum import R_M
from utils import EPS2, len2, radiansPI

from math  import cos, degrees

__all__ = ('simplify1', 'simplify2')
__version__ = '17.03.18'


def _dxy(p1, p2, adjust):
    '''(INTERNAL) Return 3-tuple (dx**2 + dy**2, dx, dy).

       If adjust is True, longitudes are adjusted
       by the cosine of the average of latitudes.
    '''
    x = p2.lon - p1.lon
    if x < -180 or x > 180:
        x = 360 - abs(x)
    if adjust:  # lon
        x *= cos(radiansPI(p1.lat + p2.lat) * 0.5)
    y = p2.lat - p1.lat
    d = x * x + y * y  # squared!
    return d, x, y


def simplify1(points, size, radius=R_M, adjust=True):
    '''Basic simplification of a path: any edges shorter than
       the given size are removed.

       @param points: Path points (LatLons).
       @param size: Edge limit (meter, same units a radius).
       @keyword radius: Earth radius (meter).
       @keyword adjust: Use adjusted longitude values (bool).

       @return: Simplified points (list of LatLons).
    '''
    n, points = len2(points)
    if n < 2:
        return points  # copy [:]

    # size in degrees squared
    s2  = degrees(float(size) / radius)
    s2 *= s2

    s2 = max(EPS2, s2)

    r = {0: True, n-1: True}  # dict avoids duplicates

    q = points[0]
    for i in range(1, n-1):
        p = points[i]
        d, _, _ = _dxy(p, q, adjust)
        if d > s2:
            r[i] = True
            q = p

    return [points[i] for i in sorted(r.keys())]


def simplify2(points, band, radius=R_M, adjust=True, radial=False):
    '''Ramer-Douglas-Peucker linearization of a path: any points
       within a given band on either side are eliminated.

       @param points: Path points (LatLons).
       @param band: Band width (meter, same units a radius).
       @keyword radius: Earth radius (meter).
       @keyword adjust: Use adjusted longitude values (bool).
       @keyword radial: Use point and line distances (bool).

       @return: Simplified points (list of LatLon).
    '''
    n, points = len2(points)
    if n < 2:
        return points  # copy [:]

    # band in degrees squared
    b2  = degrees(float(band) / radius)
    b2 *= b2

    e2 = EPS2
    if radial:
        e2 = max(e2, b2)

    r = {0: True, n-1: True}  # dict avoids duplicates

    s, e = 0, 1
    while s < e < n:
        d21, x21, y21 = _dxy(points[s], points[e], adjust)
        if d21 > e2:
            for i in range(e+1, n):
                d, x01, y01 = _dxy(points[s], points[i], adjust)
                if d > e2:
                    if radial:  # consider points ...
                        t = x21 * x01 - y21 * y01
                        if (t * t) > d21:
                            d, _, _ = _dxy(points[i], points[e], adjust)
                        elif t > 0:  # ... and triangle height
                            d  = y21 * x01 + x21 * y01
                            d *= d / d21
                    else:  # only triangle height
                        d  = y21 * x01 + x21 * y01
                        d *= d / d21
                    if d > b2:
                        r[s] = r[i] = True
                        s, e = i, i + 1
                        break  # for
            else:
                r[s] = True  # r[n-1] = True
                break  # while
        else:  # drop points[e]
            e += 1

    return [points[i] for i in sorted(r.keys())]


def simplify3(points, band, radius=R_M, adjust=True, radial=False):
    '''Ramer-Douglas-Peucker linearization of a path: any points
       within a given band on either side are eliminated.

       @param points: Path points (LatLons).
       @param band: Band width (meter, same units a radius).
       @keyword radius: Earth radius (meter).
       @keyword adjust: Use adjusted longitude values (bool).
       @keyword radial: Use point and line distances (bool).

       @return: Simplified points (list of LatLon).
    '''
    n, points = len2(points)
    if n < 2:
        return points  # copy [:]

    # band in degrees squared
    b2  = degrees(float(band) / radius)
    b2 *= b2

    e2 = EPS2
    if radial:
        e2 = max(e2, b2)

    r = {0: True, n-1: True}  # dict avoids duplicates

    st = [(0, n-1)]  # stack inlieu of recursion
    while st:
        s, e = st.pop()
        if (e - s) > 1:
            d21, x21, y21 = _dxy(points[s], points[e], adjust)
            if d21 > e2:
                m = -1
                for i in range(s+1, e):
                    # triangle points[s], -[i] and -[e]
                    d, x01, y01 = _dxy(points[s], points[i], adjust)
                    if d > e2:
                        if radial:  # consider points ...
                            t = x21 * x01 - y21 * y01
                            if (t * t) > d21:
                                d, _, _ = _dxy(points[i], points[e], adjust)
                            elif t > 0:  # ... and triangle height
                                d  = y21 * x01 + x21 * y01
                                d *= d / d21
                        else:  # only triangle height
                            d  = y21 * x01 + x21 * y01
                            d *= d / d21
                        if d > m:  # largest so far
                            if d > b2:
                                r[s] = r[i] = True
                                st.append((i, e))
                                break
                            m = d
                else:  # all inside band
                    r[s] = True
            else:  # split halfway
                m = (e - s) // 2
                st.append((m, e))
                st.append((s, m))

    return [points[i] for i in sorted(r.keys())]


def simplify4(points, band, radius=R_M, adjust=True, radial=True):
    '''Ramer-Douglas-Peucker linearization of a path: any points
       within a given band on either side are eliminated.

       @param points: Path points (LatLons).
       @param band: Band width (meter, same units a radius).
       @keyword radius: Earth radius (meter).
       @keyword adjust: Use adjusted longitude values (bool).
       @keyword radial: Use point and line distances (bool).

       @return: Simplified points (list of LatLon).
    '''
    n, points = len2(points)
    if n < 2:
        return points  # copy [:]

    # band in degrees squared
    b2  = degrees(float(band) / radius)
    b2 *= b2

    e2 = EPS2
    if radial:
        e2 = max(e2, b2)

    r = {0: True, n-1: True}  # dict avoids duplicates

    st = [(0, n-1)]  # stack inlieu of recursion
    while st:
        s, e = st.pop()
        if (e - s) > 1:

            # like GDouglasPeuker.js
            d21, x21, y21 = _dxy(points[s], points[e], adjust)
            if d21 > e2:
                dm, im = -1, s
                for i in range(s+1, e):
                    d01, x01, y01 = _dxy(points[s], points[i], adjust)
                    if radial:
                        d02, _, _ = _dxy(points[i], points[e], adjust)
                        # distance squared
                        if d01 >= (d21 + d02):
                            d = d02  # obtuse end
                        elif d02 >= (d21 + d01):
                            d = d01  # obtuse start
                        else:  # solve triangle
                            d  = x01 * y21 - y01 * x21
                            d *= d / d21
                    else:
                        d  = x01 * y21 - y01 * x21
                        d *= d / d21

                    if d > dm:  # largest
                        dm, im = d, i

                # like simplify-js
                if dm > b2:
                    r[im] = True
                    st.append((im, e))
                    st.append((s, im))
#       else:
#           r[s] = True

    return [points[i] for i in sorted(r.keys())]


def simplify5(points, band, radius=R_M, adjust=True, radial=True):
    '''Ramer-Douglas-Peucker linearization of a path: any points
       within a given band on either side are eliminated.

       @param points: Path points (L{latLon}[]).
       @param band: Band width (meter, same units a radius).
       @keyword radius: Earth radius (meter).
       @keyword adjust: Use adjusted longitude values (bool).
       @keyword radial: Use point and line distances (bool).

       @return: Simplified points (list).
    '''
    n, points = len2(points)
    if n < 2:
        return points  # copy [:]

    # band in degrees squared
    b2  = degrees(float(band) / radius)
    b2 *= b2

    e2 = EPS2
    if radial:
        e2 = max(e2, b2)

    r = {0: True, n-1: True}  # dict avoids duplicates

    st = [(0, n-1)]
    while st:
        dm = im = -1
        s, e = st.pop()
        if (e - s) > 1:

            d12, x12, y12 = _dxy(points[s], points[e], adjust)
            if d21 > e2:
                for i in range(s+1, e):
                    d01, x01, y01 = _dxy(points[s], points[i], adjust)
                    if radial:
                        d02, _, _ = _dxy(points[i], points[e], adjust)
                        # distance squared
                        if d01 >= (d21 + d02):
                            d = d02  # obtuse end
                        elif d02 >= (d21 + d01):
                            d = d01  # obtuse start
                        else:  # solve triangle
                            d  = x01 * y21 - y01 * x21
                            d *= d / d21
                    else:
                        d  = x01 * y21 - y01 * x21
                        d *= d / d21

                    if d > dm:  # largest
                        dm, im = d, i
                if dm > b2:
                    r[im] = True
                    st.append((im, e))
                    st.append((s, im))
            else:  # split halfway
            i = (e - s) // 2
                st.append((i, e))
                st.append((s, i))

    return [points[i] for i in sorted(r.keys())]
